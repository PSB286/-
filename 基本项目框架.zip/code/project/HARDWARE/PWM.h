#ifndef __PWM_H
#define __PWM_H

void PWM_Init();
void PWM_SetCompare2(uint16 Compare);

#endif
