#ifndef _FIRE_H_
#define _FIRE_H_

#include "stm32f10x.h"


#define GPIO_FIRE_RCC  RCC_APB2Periph_GPIOA
#define GPIO_FIRE_PORT GPIOA//ѡ��GPIOA�Ĵ���
#define GPIO_FIRE_PIN  GPIO_Pin_1 //����1


void FIRE_CONFIG(void	);


#endif
