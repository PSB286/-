#ifndef __Servo_H
#define __Servo_H

void Servo_Init(void);
void Servo_SetAngle(float Angle);

#endif

